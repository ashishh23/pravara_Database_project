<?php 


$servername = "localhost";

// User Name Specified Below
$username = "root";

$password = "";

$db = "sse";

$con = mysqli_connect($servername, $username, $password, $db) or die("Error Connection Database");



?>
<!-- Auth miracle devlopers :: PHP Version : 7.4.3 -->