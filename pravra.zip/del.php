<?php 


$sno = $_GET['sno'];
include("connection.php");
$mysqldelete = "DELETE FROM `info` WHERE sno=$sno";
$delq = mysqli_query($con, $mysqldelete);
if($delq) {
    header("LOCATION: Data.php");
}

?>