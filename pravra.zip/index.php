<!DOCTYPE html>
<html lang="en-US" prefix="og: https://ogp.me/ns#">
<?php include("headtag.php");
require("connection.php"); ?>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">

<link rel="stylesheet" href="Assets/ashu.css">


<title>Pravra </title>
</head>

<body
    class="page-template page-template-contact-page page-template-contact-page-php page page-id-1452 qode-quick-links-1.0  qode-title-hidden qode-theme-ver-12.1.1 qode-theme-bridge wpb-js-composer js-comp-ver-6.0.5 vc_responsive"
    itemscope itemtype="http://schema.org/WebPage">
    <!--  Clickcease.com tracking-->
    <script type="text/javascript">
    var script = document.createElement("script");
    script.async = true;
    script.type = "text/javascript";
    var target = 'https://www.clickcease.com/monitor/stat.js';
    script.src = target;
    var elem = document.head;
    elem.appendChild(script);
    </script>
    <noscript><a href="https://www.clickcease.com" rel="nofollow"><img
                src="https://monitor.clickcease.com/stats/stats.aspx" alt="ClickCease" /></a></noscript>
    <!--  Clickcease.com tracking-->

    <div class="wrapper">
        <div class="wrapper_inner">


            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-112462302-1"></script>
            <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'UA-112462302-1');
            </script>

            <form method="POST">

                <div class="background">
                    <div class="container">
                        <div class="screen">
                            <div class="screen-header">
                                <div class="screen-header-left">
                                    <div class="screen-header-button close"></div>
                                    <div class="screen-header-button maximize"></div>
                                    <div class="screen-header-button minimize"></div>
                                </div>
                                <div class="screen-header-right">
                                    <div class="screen-header-ellipsis"></div>
                                    <div class="screen-header-ellipsis"></div>
                                    <div class="screen-header-ellipsis"></div>
                                </div>
                            </div>
                            <div class="screen-body">
                                <div class="screen-body-item left">
                                    <div class="app-title">
                                        <span>Placement</span>
                                        <span>Information</span>
                                    </div>
                                    <div class="app-contact">CONTACT INFO : Pravra Rural Engg. College loni</div>
                                </div>
                                <div class="screen-body-item">
                                    <div class="app-form">
                                        <div class="app-form-group">
                                            <input class="app-form-control" name="your-firstname"
                                                placeholder="First Name">
                                        </div>
                                        <div class="app-form-group">
                                            <input class="app-form-control" name="your-lastname"
                                                placeholder="Last Name">
                                        </div>
                                        <div class="app-form-group">
                                            <input class="app-form-control" type="email" name="your-email"
                                                placeholder="EMAIL">
                                        </div>
                                        <div class="app-form-group">
                                            <input class="app-form-control" name="pac" placeholder="Package in Lac ">
                                        </div>
                                        <div class="app-form-group message">
                                            <input class="app-form-control" name="com" placeholder="COMPANY NAME">
                                        </div>
                                        <div class="app-form-group buttons">
                                            <button class="app-form-button" type="clear">CANCEL</button>
                                            <button class="app-form-button" type="submit" name="submit">SEND</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>


            </form>



            <?php
        // Auth --> Ashuu
        // PHP Version --> 7.4.3


        if (isset($_POST['submit'])) {
            $first_name = $_POST['your-firstname'];
            $last_name = $_POST['your-lastname'];
            $phone_no = $_POST['pac'];
            $email_ad = $_POST['your-email'];
            $msg_user = $_POST['com'];
            $insert_query = "INSERT INTO `info`(`first_name`, `last_name`, `email`, `pac`, `com`) VALUES ('$first_name','$last_name','$email_ad','$phone_no','$msg_user')";
            $query = mysqli_query($con, $insert_query);
            if ($query) {
                echo "<script>alert('Message Sent');</script>";
            } else {
                echo "<script>alert('Internal Server Error');</script>";
            }
        }


        ?>


        </div>
    </div>
    </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner">
            <div class="wpb_wrapper"></div>
        </div>
    </div>
    </div>
    </div>
    <div class="vc_row wpb_row section vc_row-fluid " style=' text-align:left;'>
        <div class=" full_section_inner clearfix">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                        <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner">
                                <span class="empty_space_image"></span>
                            </span></div>






                        <div class="wpb_text_column wpb_content_element ">
                            <div class="wpb_wrapper">


                            


                            </div>
                        </div>
                        <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner">
                                <span class="empty_space_image"></span>
                            </span></div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>



    </div>
    </div>



    </div>
    </div>
    <script type="text/javascript">
(function(grecaptcha, sitekey, actions) {

    var wpcf7recaptcha = {

        execute: function(action) {
            grecaptcha.execute(
                sitekey, {
                    action: action
                }
            ).then(function(token) {
                var forms = document.getElementsByTagName('form');

                for (var i = 0; i < forms.length; i++) {
                    var fields = forms[i].getElementsByTagName('input');

                    for (var j = 0; j < fields.length; j++) {
                        var field = fields[j];

                        if ('g-recaptcha-response' === field.getAttribute('name')) {
                            field.setAttribute('value', token);
                            break;
                        }
                    }
                }
            });
        },

        executeOnHomepage: function() {
            wpcf7recaptcha.execute(actions['homepage']);
        },

        executeOnContactform: function() {
            wpcf7recaptcha.execute(actions['contactform']);
        },

    };

    grecaptcha.ready(
        wpcf7recaptcha.executeOnHomepage
    );

    document.addEventListener('change',
        wpcf7recaptcha.executeOnContactform, false
    );

    document.addEventListener('wpcf7submit',
        wpcf7recaptcha.executeOnHomepage, false
    );

})(
    grecaptcha,
    '6LeGTMUUAAAAALnEdfoMdpF4qARqzHeG7fSj1Zo2', {
        "homepage": "homepage",
        "contactform": "contactform"
    }
);
</script>
</body>

</html>